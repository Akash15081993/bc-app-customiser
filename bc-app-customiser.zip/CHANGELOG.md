All notable changes to this project will be documented in this file. See Conventional Commits for commit guidelines

### 1.0.0

- Initial public release
